<?php
/**
 * System messages translation for CodeIgniter(tm)
 *
 * @author	CodeIgniter community
 * @copyright	Copyright (c) 2014 - 2016, British Columbia Institute of Technology (http://bcit.ca/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://codeigniter.com
 */
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['cal_su']			= 'So';
$lang['cal_mo']			= 'Mo';
$lang['cal_tu']			= 'Di';
$lang['cal_we']			= 'Mi';
$lang['cal_th']			= 'Do';
$lang['cal_fr']			= 'Fr';
$lang['cal_sa']			= 'Sa';
$lang['cal_sun']		= 'Son';
$lang['cal_mon']		= 'Mon';
$lang['cal_tue']		= 'Die';
$lang['cal_wed']		= 'Mit';
$lang['cal_thu']		= 'Don';
$lang['cal_fri']		= 'Fre';
$lang['cal_sat']		= 'Sam';
$lang['cal_sunday']		= 'Sonntag';
$lang['cal_monday']		= 'Montag';
$lang['cal_tuesday']	= 'Dienstag';
$lang['cal_wednesday']	= 'Mittwoch';
$lang['cal_thursday']	= 'Donnerstag';
$lang['cal_friday']		= 'Freitag';
$lang['cal_saturday']	= 'Samstag';
$lang['cal_jan']		= 'Jan';
$lang['cal_feb']		= 'Feb';
$lang['cal_mar']		= 'Mär';
$lang['cal_apr']		= 'Apr';
$lang['cal_may']		= 'Mai';
$lang['cal_jun']		= 'Jun';
$lang['cal_jul']		= 'Jul';
$lang['cal_aug']		= 'Aug';
$lang['cal_sep']		= 'Sep';
$lang['cal_oct']		= 'Okt';
$lang['cal_nov']		= 'Nov';
$lang['cal_dec']		= 'Dez';
$lang['cal_january']	= 'Januar';
$lang['cal_february']	= 'Februar';
$lang['cal_march']		= 'März';
$lang['cal_april']		= 'April';
$lang['cal_mayl']		= 'Mai';
$lang['cal_june']		= 'Juni';
$lang['cal_july']		= 'Juli';
$lang['cal_august']		= 'August';
$lang['cal_september']	= 'September';
$lang['cal_october']	= 'Oktober';
$lang['cal_november']	= 'November';
$lang['cal_december']	= 'Dezember';
