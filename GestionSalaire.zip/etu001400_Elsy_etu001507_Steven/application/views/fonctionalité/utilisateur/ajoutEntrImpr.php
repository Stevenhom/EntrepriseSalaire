<?php 
    $this->load->helper('url_helper');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>imprevue</title>
    <!-- <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Bitter:400,700">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lora">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/css/Article-Clean.css">
    <link rel="stylesheet" href="assets/css/Contact-Form-Clean.css">
    <link rel="stylesheet" href="assets/css/Dark-NavBar-1.css">
    <link rel="stylesheet" href="assets/css/Dark-NavBar-2.css">
    <link rel="stylesheet" href="assets/css/Dark-NavBar.css">
    <link rel="stylesheet" href="assets/css/Footer-Basic.css">
    <link rel="stylesheet" href="assets/css/Footer-Clean.css">
    <link rel="stylesheet" href="assets/css/Footer-Dark.css">
    <link rel="stylesheet" href="assets/css/Header-Dark.css">
    <link rel="stylesheet" href="assets/css/Pretty-Login-Form.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/Testimonials.css"> -->
    <link rel="stylesheet" href="<?php echo site_url('assets/bootstrap/css/bootstrap.min.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('https://fonts.googleapis.com/css?family=Bitter:400,700 '); ?>">
    <link rel="stylesheet" href="<?php echo site_url('https://fonts.googleapis.com/css?family=Lora'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/fonts/font-awesome.min.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/fonts/ionicons.min.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Article-Clean.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Dark-NavBar-1.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Dark-NavBar-2.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Dark-NavBar.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Footer-Basic.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Footer-Clean.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Footer-Dark.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Header-Dark.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/styles.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Testimonials.css'); ?>">
</head>

<body>
<div>
        <nav class="navbar navbar-light navbar-expand-md sticky-top navigation-clean-button" style="height: 80px;background-color: #4aadff;color: #ffffff;">
            <div class="container-fluid"><a class="navbar-brand" href="#"><i class="fa fa-globe"></i>&nbsp;Domicile</a><button data-bs-toggle="collapse" class="navbar-toggler" data-bs-target="#navcol-1"><span class="visually-hidden">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navcol-1">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item"><a class="nav-link active" style="color:#ffffff;" href="#"><i class="fa fa-home"></i>&nbsp;Acceuil</a></li>
                        <li class="nav-item"><a class="nav-link active" style="color:#ffffff;" href="<?php echo site_url('index.php/login/tableauMensuel');?>"><i class="fa fa-wpexplorer"></i>&nbsp;tableau mensuel</a></li>
                        <li class="nav-item"><a class="nav-link active" style="color:#ffffff;" href="<?php echo site_url('index.php/login/tabMensDepBenef');?>"><i class="fa fa-wpexplorer"></i>&nbsp;tableau mensuel par bénéficiaire</a></li>
                        <li class="nav-item"><a class="nav-link active" style="color:#ffffff;" href="<?php echo site_url('index.php/login/formEntrImpr')?>"><i class="fa fa-wpexplorer"></i>&nbsp;Imprévu</a></li>
                        <li class="nav-item"></li>
                        <li class="nav-item"><a class="nav-link active" style="color:#ffffff;" href="<?php echo site_url('index.php/login/formAjoutDepense');?>"><i class="fa fa-user-circle-o"></i>&nbsp;Dépense</a></li>
                        <li class="nav-item"><a class="nav-link active" style="color:#ffffff;" href="#"><i class="fa fa-sign-in"></i>&nbsp;Sign In</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </div>

    <section class="contact-clean">
        <form action="<?php echo site_url('index.php/login/ajoutEntrImpr')?>" method="post">
            <h2 class="text-center">Imprévue</h2>
            <?php if(isset($_GET['error'])) { ?>
            <p style="color: red; margin-left:1%;"><?php echo $this->input->get('error'); ?></p>
        <?php } ?>
        <?php if(isset($_GET['succes'])) { ?>
            <p style="color: green; margin-left:1%;"><?php echo $this->input->get('succes'); ?></p>
        <?php } ?>
            <div class="mb-3"><input class="form-control" type="text" name="nom" required placeholder="Nom bénéficiaire"></div>
            <div class="mb-3"><input class="form-control" type="text" required name="montant" placeholder="Montant"></div>
            <div class="mb-3"><textarea class="form-control" name="motif" required placeholder="Motif" rows="10"></textarea></div>
            <div class="mb-3"><input class="form-control" required type="date" name="date" placeholder="Date"></div> 
            <div class="mb-3"><button class="btn btn-primary" type="submit">Ajouter</button></div>
        </form>
    </section>
    <footer class="footer-basic">
        <div class="social"><a href="#"><i class="icon ion-social-instagram"></i></a><a href="#"><i class="icon ion-social-snapchat"></i></a><a href="#"><i class="icon ion-social-twitter"></i></a><a href="#"><i class="icon ion-social-facebook"></i></a></div>
        <p class="copyright">ETU001507 Steven_ ETU001400 Elsy&nbsp;</p>
    </footer>
    <script src="<?php echo site_url('assets/bootstrap/js/bootstrap.min.js');?>"></script>
</body>

</html>