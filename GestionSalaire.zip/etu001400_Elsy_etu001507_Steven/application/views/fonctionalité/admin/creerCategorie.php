<?php
    $this->load->helper('url_helper');
?>
<!-- <!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Créer catégorie</title>
    </head>
    <body>
        <h2>Créer catégorie</h2>
        <?php if(isset($_GET['succes'])) { ?>
            <p style="color: green;"><?php echo $this->input->get('succes'); ?></p>
        <?php } ?>
        <form action="<?php echo site_url('index.php/login/ajoutCategorie')?>" method="post">
            <p><input type="text" name="nom" placeholder="Nom" required></p>
            <p><input type="text" name="budget" placeholder="Budget" required></p>
            <p><input type="submit" value="créer"> <input type="button" value="retour" onclick="location='<?php echo site_url('index.php/login/admin');?>'"></p>
        </form>
        <footer>
            CHARLES ETU001400 - RAZAFIMAHERY ETU1507
        </footer>
    </body>
</html> -->




<?php 
    $this->load->helper('url_helper');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>salaire</title>
    <link rel="stylesheet" href="<?php echo site_url('assets/bootstrap/css/bootstrap.min.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('https://fonts.googleapis.com/css?family=Bitter:400,700 '); ?>">
    <link rel="stylesheet" href="<?php echo site_url('https://fonts.googleapis.com/css?family=Lora'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/fonts/font-awesome.min.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/fonts/ionicons.min.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Article-Clean.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Dark-NavBar-1.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Dark-NavBar-2.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Dark-NavBar.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Footer-Basic.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Footer-Clean.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Footer-Dark.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Header-Dark.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/styles.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Testimonials.css'); ?>">
</head>

<body style="height: 649px;margin-top: 0px;margin-bottom: 0px;padding-top: 0px;">
<div>
        <nav class="navbar navbar-light navbar-expand-md sticky-top navigation-clean-button" style="height: 80px;background-color: #4aadff;color: #ffffff;margin-bottom: 0px;margin-top: 0px;">
            <div class="container-fluid"><a class="navbar-brand" href="#"><i class="fa fa-globe"></i>&nbsp;Domicile</a><button data-bs-toggle="collapse" class="navbar-toggler" data-bs-target="#navcol-1"><span class="visually-hidden">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navcol-1">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item"><a class="nav-link active" style="color:#ffffff;" href="#"><i class="fa fa-home"></i>&nbsp;Acceuil</a></li>
                        <li class="nav-item"><a class="nav-link active" style="color:#ffffff;" href="<?php echo site_url('index.php/login/formCreerCategorie');?>"><i class="fa fa-wpexplorer"></i>&nbsp;Catégorie</a></li>
                        <li class="nav-item"><a class="nav-link active" style="color:#ffffff;" href="<?php echo site_url('index.php/login/formCreerSalaireMensuel');?>"><i class="fa fa-wpexplorer"></i>&nbsp;Salaire</a></li>
                        <li class="nav-item"></li>
                        <li class="nav-item"><a class="nav-link active" style="color:#ffffff;" href="<?php echo site_url('index.php/login/formGestionUtilisateur');?>"><i class="fa fa-user-circle-o"></i>&nbsp;Utilisateur</a></li>
                        <li class="nav-item"><a class="nav-link active" style="color:#ffffff;" href="<?php echo site_url('index.php/login/formGestionBeneficiaire');?>"><i class="fa fa-user-circle-o"></i>&nbsp;Bénéficiaire</a></li>
                        <li class="nav-item"><a class="nav-link active" style="color:#ffffff;" href="#"><i class="fa fa-sign-in"></i>&nbsp;Sign In</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <section class="newsletter-subscribe" style="display: block;margin-top: 150px;margin-right: auto;margin-left: auto;padding-right: auto;width: 700px;border-radius: 10px;">
                    <div class="container">
                        <h2>Créer catégorie</h2>
        <?php if(isset($_GET['succes'])) { ?>
            <p style="color: green;"><?php echo $this->input->get('succes'); ?></p>
        <?php } ?>
        <form action="<?php echo site_url('index.php/login/ajoutCategorie')?>" method="post">
            <p><input type="text" name="nom" placeholder="Nom" required></p>
            <p><input type="text" name="budget" placeholder="Budget" required></p>
            <p><input type="submit" value="créer"> <input type="button" value="retour" onclick="location='<?php echo site_url('index.php/login/admin');?>'"></p>
        </form>
                    </div>
                </section>
            </div>
        </div>
    </div>
    <footer class="footer-basic" style="height: 250px;">
        <div class="social"><a href="#"><i class="icon ion-social-instagram"></i></a><a href="#"><i class="icon ion-social-snapchat"></i></a><a href="#"><i class="icon ion-social-twitter"></i></a><a href="#"><i class="icon ion-social-facebook"></i></a></div>
        <p class="copyright">ETU001507 Steven_ ETU001400 Elsy&nbsp;</p>
    </footer>
    <script src="<?php echo site_url('assets/bootstrap/js/bootstrap.min.js')?>"></script>
</body>

</html>