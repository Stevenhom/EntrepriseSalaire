<!-- <?php 
    $this->load->helper('url_helper');
?>
<!DOCTYPE html>
<html lang="en" style="height: 650px;">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>beneficiaire</title>
    <link rel="stylesheet" href="<?php echo site_url('assets/bootstrap/css/bootstrap.min.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('https://fonts.googleapis.com/css?family=Bitter:400,700 '); ?>">
    <link rel="stylesheet" href="<?php echo site_url('https://fonts.googleapis.com/css?family=Lora'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/fonts/font-awesome.min.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/fonts/ionicons.min.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Article-Clean.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Dark-NavBar-1.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Dark-NavBar-2.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Dark-NavBar.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Footer-Basic.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Footer-Clean.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Footer-Dark.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Header-Dark.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/styles.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Testimonials.css'); ?>">
</head>

<body style="height: 649px;margin-top: 0px;margin-bottom: 0px;padding-top: 0px;">
    <div>
        <nav class="navbar navbar-light navbar-expand-md sticky-top navigation-clean-button" style="height: 80px;background-color: #4aadff;color: #ffffff;margin-bottom: 0px;margin-top: 0px;">
            <div class="container-fluid"><a class="navbar-brand" href="#"><i class="fa fa-globe"></i>&nbsp;Domicile</a><button data-bs-toggle="collapse" class="navbar-toggler" data-bs-target="#navcol-1"><span class="visually-hidden">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navcol-1">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item"><a class="nav-link active" style="color:#ffffff;" href="#"><i class="fa fa-home"></i>&nbsp;Acceuil</a></li>
                        <li class="nav-item"><a class="nav-link active" style="color:#ffffff;" href="<?php echo site_url('index.php/login/formCreerCategorie');?>"><i class="fa fa-wpexplorer"></i>&nbsp;Catégorie</a></li>
                        <li class="nav-item"><a class="nav-link active" style="color:#ffffff;" href="<?php echo site_url('index.php/login/formCreerSalaireMensuel');?>"><i class="fa fa-wpexplorer"></i>&nbsp;Salaire</a></li>
                        <li class="nav-item"></li>
                        <li class="nav-item"><a class="nav-link active" style="color:#ffffff;" href="<?php echo site_url('index.php/login/formGestionUtilisateur');?>"><i class="fa fa-user-circle-o"></i>&nbsp;Utilisateur</a></li>
                        <li class="nav-item"><a class="nav-link active" style="color:#ffffff;" href="<?php echo site_url('index.php/login/formGestionBeneficiaire');?>"><i class="fa fa-user-circle-o"></i>&nbsp;Bénéficiaire</a></li>
                        <li class="nav-item"><a class="nav-link active" style="color:#ffffff;" href="#"><i class="fa fa-sign-in"></i>&nbsp;Sign In</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </div>
    <section class="article-clean"></section>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <section class="article-clean">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-10 col-xl-8 offset-lg-1 offset-xl-2">
                                <div class="intro">
                                    <h1 class="text-center">Gestion des Bénéficiaires</h1>
                                </div>
                                <div class="text"></div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <section class="contact-clean">
                    <form method="post" action="<?php echo site_url('index.php/login/ajoutBeneficiaire')?>">
                        <h2 class="text-center">Ajout</h2>
                        <?php if(isset($_GET['succes'])) { ?>
                <p style="color: green;"><?php echo $this->input->get('succes'); ?></p>
            <?php } ?>
                        <div class="mb-3"><input class="form-control" type="text" name="nom" placeholder="Nom"></div>
                        <div class="mb-3"><input class="form-control" type="password" name="motdepasse" placeholder="Mot de passe"></div>
                        <div class="mb-3"></div>
                        <div class="mb-3"><button class="btn btn-primary" type="submit">AJOUTER</button></div>
                    </form>
                </section>
            </div>
            <div class="col-md-4">
                <section class="contact-clean">
                    <form method="post" action="<?php echo site_url('index.php/login/supprBeneficiaire')?>">
                        <h2 class="text-center">&nbsp;Suppression</h2>
                        <?php if(isset($_GET['succes1'])) { ?>
                <p style="color: green;"><?php echo $this->input->get('succes1'); ?></p>
            <?php } ?>
            <div class="mb-3"><input class="form-control" type="text" name="nom" placeholder="Nom"></div>
                        <div class="mb-3"><input class="form-control" type="password" name="motdepasse" placeholder="Mot de passe"></div>
                        <div class="mb-3"></div>
                        <div class="mb-3"><button class="btn btn-primary" type="submit">SUPPRIMER</button></div>
                    </form>
                </section>
            </div>
            <div class="col-md-4">
                <section class="contact-clean">
                    <form method="post" action="<?php echo site_url('index.php/login/modifBeneficiaire')?>">
                        <h2 class="text-center">Modification</h2>
                        <?php if(isset($_GET['succes2'])) { ?>
                <p style="color: green;"><?php echo $this->input->get('succes2'); ?></p>
            <?php } ?>
            <div class="mb-3"><input class="form-control" type="text" name="nom" placeholder="Nom"></div>
                        <div class="mb-3"><input class="form-control" type="password" name="motdepasse" placeholder="Mot de passe"></div>
                        <div class="mb-3"></div>
                        <div class="mb-3"><button class="btn btn-primary" type="submit">MODIFIER</button></div>
                    </form>
                </section>
            </div>
        </div>
    </div>
    <footer class="footer-basic" style="margin-bottom: 0px;margin-top: 71px;">
        <div class="social"><a href="#"><i class="icon ion-social-instagram"></i></a><a href="#"><i class="icon ion-social-snapchat"></i></a><a href="#"><i class="icon ion-social-twitter"></i></a><a href="#"><i class="icon ion-social-facebook"></i></a></div>
        <p class="copyright">ETU001507 Steven_ ETU001400 Elsy&nbsp;</p>
    </footer>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html> -->

<?php 
    $this->load->helper('url_helper');
?>
<!DOCTYPE html>
<html lang="en" style="height: 650px;">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>beneficiaire</title>
    <link rel="stylesheet" href="<?php echo site_url('assets/bootstrap/css/bootstrap.min.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('https://fonts.googleapis.com/css?family=Bitter:400,700 '); ?>">
    <link rel="stylesheet" href="<?php echo site_url('https://fonts.googleapis.com/css?family=Lora'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/fonts/font-awesome.min.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/fonts/ionicons.min.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Article-Clean.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Dark-NavBar-1.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Dark-NavBar-2.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Dark-NavBar.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Footer-Basic.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Footer-Clean.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Footer-Dark.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Header-Dark.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/styles.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Testimonials.css'); ?>">
</head>

<body style="height: 649px;margin-top: 0px;margin-bottom: 0px;padding-top: 0px;">
    <div>
        <nav class="navbar navbar-light navbar-expand-md sticky-top navigation-clean-button" style="height: 80px;background-color: #4aadff;color: #ffffff;margin-bottom: 0px;margin-top: 0px;">
            <div class="container-fluid"><a class="navbar-brand" href="#"><i class="fa fa-globe"></i>&nbsp;Domicile</a><button data-bs-toggle="collapse" class="navbar-toggler" data-bs-target="#navcol-1"><span class="visually-hidden">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navcol-1">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item"><a class="nav-link active" style="color:#ffffff;" href="#"><i class="fa fa-home"></i>&nbsp;Acceuil</a></li>
                        <li class="nav-item"><a class="nav-link active" style="color:#ffffff;" href="<?php echo site_url('index.php/login/formCreerCategorie');?>"><i class="fa fa-wpexplorer"></i>&nbsp;Catégorie</a></li>
                        <li class="nav-item"><a class="nav-link active" style="color:#ffffff;" href="<?php echo site_url('index.php/login/formCreerSalaireMensuel');?>"><i class="fa fa-wpexplorer"></i>&nbsp;Salaire</a></li>
                        <li class="nav-item"></li>
                        <li class="nav-item"><a class="nav-link active" style="color:#ffffff;" href="<?php echo site_url('index.php/login/formGestionUtilisateur');?>"><i class="fa fa-user-circle-o"></i>&nbsp;Utilisateur</a></li>
                        <li class="nav-item"><a class="nav-link active" style="color:#ffffff;" href="<?php echo site_url('index.php/login/formGestionBeneficiaire');?>"><i class="fa fa-user-circle-o"></i>&nbsp;Bénéficiaire</a></li>
                        <li class="nav-item"><a class="nav-link active" style="color:#ffffff;" href="#"><i class="fa fa-sign-in"></i>&nbsp;Sign In</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </div>
    <section class="article-clean"></section>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <section class="article-clean">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-10 col-xl-8 offset-lg-1 offset-xl-2">
                                <div class="intro">
                                    <h1 class="text-center">Gestion des Bénéficiaires</h1>
                                </div>
                                <div class="text"></div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <section class="contact-clean">
                    <form method="post" action="<?php echo site_url('index.php/login/ajoutBeneficiaire')?>">
                        <h2 class="text-center">Ajout</h2>
                        <?php if(isset($_GET['succes'])) { ?>
                <p style="color: green;"><?php echo $this->input->get('succes'); ?></p>
            <?php } ?>
                        <div class="mb-3"><input class="form-control" type="text" name="nom" placeholder="Nom"></div>
                        <div class="mb-3"><input class="form-control" type="password" name="motdepasse" placeholder="Mot de passe"></div>
                        <div class="mb-3"></div>
                        <div class="mb-3"><button class="btn btn-primary" type="submit">AJOUTER</button></div>
                    </form>
                </section>
            </div>
            <div class="col-md-4">
                <section class="contact-clean">
                    <form method="post" action="<?php echo site_url('index.php/login/supprBeneficiaire')?>">
                        <h2 class="text-center">&nbsp;Suppression</h2>
                        <?php if(isset($_GET['succes1'])) { ?>
                <p style="color: green;"><?php echo $this->input->get('succes1'); ?></p>
            <?php } ?>
            <div class="mb-3"><input class="form-control" type="text" name="nom" placeholder="Nom"></div>
                        <div class="mb-3"><input class="form-control" type="password" name="motdepasse" placeholder="Mot de passe"></div>
                        <div class="mb-3"></div>
                        <div class="mb-3"><button class="btn btn-primary" type="submit">SUPPRIMER</button></div>
                    </form>
                </section>
            </div>
            <div class="col-md-4">
                <section class="contact-clean">
                    <form method="post" action="<?php echo site_url('index.php/login/modifBeneficiaire')?>">
                        <h2 class="text-center">Modification</h2>
                        <?php if(isset($_GET['succes2'])) { ?>
                <p style="color: green;"><?php echo $this->input->get('succes2'); ?></p>
            <?php } ?>
            <div class="mb-3"><input class="form-control" type="text" name="nom" placeholder="Nom"></div>
                        <div class="mb-3"><input class="form-control" type="password" name="motdepasse" placeholder="Mot de passe"></div>
                        <h4>Modification en</h4>
                        <div class="mb-3"><input class="form-control" type="text" name="nommodif" placeholder="Nom"></div>
                        <div class="mb-3"><input class="form-control" type="password" name="motdepassemodif" placeholder="Mot de passe"></div>
                        <div class="mb-3"></div>
                        <div class="mb-3"><button class="btn btn-primary" type="submit">MODIFIER</button></div>
                    </form>
                </section>
            </div>
        </div>
    </div>
    <footer class="footer-basic" style="margin-bottom: 0px;margin-top: 71px;">
        <div class="social"><a href="#"><i class="icon ion-social-instagram"></i></a><a href="#"><i class="icon ion-social-snapchat"></i></a><a href="#"><i class="icon ion-social-twitter"></i></a><a href="#"><i class="icon ion-social-facebook"></i></a></div>
        <p class="copyright">ETU001507 Steven_ ETU001400 Elsy&nbsp;</p>
    </footer>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>