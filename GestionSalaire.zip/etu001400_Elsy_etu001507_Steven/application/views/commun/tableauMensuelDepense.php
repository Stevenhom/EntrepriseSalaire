<?php
    $this->load->helper('url_helper');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau mensuel dépense par bénéficiaire</title>
    <title>salaire</title>
    <link rel="stylesheet" href="<?php echo site_url('assets/bootstrap/css/bootstrap.min.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('https://fonts.googleapis.com/css?family=Bitter:400,700 '); ?>">
    <link rel="stylesheet" href="<?php echo site_url('https://fonts.googleapis.com/css?family=Lora'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/fonts/font-awesome.min.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/fonts/ionicons.min.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Article-Clean.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Dark-NavBar-1.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Dark-NavBar-2.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Dark-NavBar.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Footer-Basic.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Footer-Clean.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Footer-Dark.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Header-Dark.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/styles.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('assets/css/Testimonials.css'); ?>">
</head>
<body>

<div>
    </div>
    <h2>Tableau mensuel dépense par bénéficiaire</h2>
    <table border="1" class="table table-dark">
        <tr>
            <th>idbeneficiaire</th>
            <th>depensemontant</th>
            <th>mois</th>
        </tr>
       
            <?php 
                for ($i=0; $i < sizeof($datas); $i++) 
                { 
                    echo '<tr scope="col">';
                    echo '<th scope="col">'.$datas[$i]['idbeneficiaire'].'</th>';
                    echo '<th scope="col">'.$datas[$i]['depensemontant'].'</th>';
                    echo '<th scope="col">'.$datas[$i]['mois'].'</th>';
                    echo '</tr>';
                }
            ?>
    </table>
    <footer>
        CHARLES ETU001400 - RAZAFIMAHERY ETU1507
    </footer>
</body>
</html>