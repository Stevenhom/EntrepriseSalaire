
<?php 
    $this->load->helper('url_helper');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Login</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/css/Contact-Form-Clean.css">
    <link rel="stylesheet" href="assets/css/Footer-Basic.css">
    <link rel="stylesheet" href="assets/css/Highlight-Clean.css">
    <link rel="stylesheet" href="assets/css/Login-Form-Dark.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
    <section class="contact-clean">
        <form action="<?php echo site_url('index.php/login/testLogin');?>" method="post">
            <h2 class="text-center">Connectez-vous</h2>
            <?php if(isset($_GET['error'])) { ?>
            <p style="color: red; margin-left:30%"><?php echo $this->input->get('error'); ?></p>
            <?php } ?>
            <div class="mb-3"><input class="form-control" type="text" value="Jean" name="nom" placeholder="Nom"></div>
            <div class="mb-3"><input class="form-control" type="password" value="jean" name="motdepasse" placeholder="Mot de passe"></div>
            <div class="mb-3"></div>
            <div class="mb-3"><button class="btn btn-primary" type="submit">Connexion</button></div>
        </form>
    </section>
    <footer class="footer-basic">
        <div class="social"><a href="#"><i class="icon ion-social-instagram"></i></a><a href="#"><i class="icon ion-social-snapchat"></i></a><a href="#"><i class="icon ion-social-twitter"></i></a><a href="#"><i class="icon ion-social-facebook"></i></a></div>
        <p class="copyright"><br>ETU001507 Steven_ ETU001400 Elsy&nbsp;<br><br></p>
    </footer>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>