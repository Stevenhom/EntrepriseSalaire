<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->load->view('login');
	}

	public function testLogin()
	{
		$this->load->model('models');
		$this->load->helper('url');
		$this->load->helper('url_helper');
		
		$nom = $this->input->post('nom');
		$motdepasse = $this->input->post('motdepasse');
		
		if ($this->models->isLogable($nom, $motdepasse)) 
		{
			if ($this->models->isAdmin($nom, $motdepasse) == true) 
			{
				$this->load->view('accueil/admin');
			}
			else
			{
				$this->load->view('accueil/utilisateur');
			}
		}
		else
		{
			redirect(site_url('index.php').'?error=Erreur de connexion !');
		}
	}

	public function admin()
	{
		$this->load->view('accueil/admin');
	}

	public function utilisateur()
	{
		$this->load->view('accueil/utilisateur');
	}

	public function formAjoutDepense()
	{
		$this->load->model('models');		
		$this->load->view('fonctionalité/utilisateur/ajoutDepense');
	}

	public function formEntrImpr()
	{
		$this->load->view('fonctionalité/utilisateur/ajoutEntrImpr');
	}

	public function formCreerCategorie()
	{
		$this->load->view('fonctionalité/admin/creerCategorie');
	}

	public function formCreerSalaireMensuel ()
	{
		$this->load->view('fonctionalité/admin/creerSalaireMensuel');
	}

	public function formGestionUtilisateur()
	{
		$this->load->view('fonctionalité/admin/gestionUtilisateur');
	}

	public function formGestionBeneficiaire()
	{
		$this->load->view('fonctionalité/admin/gestionBeneficiaire');
	}


	public function ajoutDepense()
	{
		$this->load->model('models');
		$this->load->helper('url');

		$idbeneficiaire = $this->models->getDataConditionated('beneficiaire', ['idbeneficiaire'], ['nom'],[$this->input->post('nom')]);

		$idcategorie = $this->models->getDataConditionated('categorie', ['idcategorie'], ['nom'],[$this->input->post('type')]);


		if (sizeof($idbeneficiaire) != 0) 
		{
			if (sizeof($idcategorie) != 0) 
			{
				$data =  $this->models->getDataConditionated('v_budget', ['depense', 'montant'], ['idcategorie'], [$idcategorie[0]['idcategorie']]);
				echo $data[0]['depense'];
				if ($data[0]['depense'] + $this->input->post('montant') < $data[0]['montant']) 
				{
					$this->models->insert('depense', ['idbeneficiaire', 'idcategorie', 'datedepense', 'montant'], [$idbeneficiaire[0]['idbeneficiaire'], $idcategorie[0]['idcategorie'], $this->input->post('date'), $this->input->post('montant')]);
					redirect(site_url('index.php/login/formAjoutDepense').'?succes=Inséré avec succes !');		
				}
				else
				{
					// redirect(site_url('index.php/login/formAjoutDepense').'?confirmation&idbeneficiaire='.$idbeneficiaire[0]['idbeneficiaire'].'&idcategorie='.$idcategorie[0]['idcategorie'].'&datedepense='.$this->input->post('date').'&montant='.$this->input->post('montant'));
					redirect(site_url('index.php/login/formAjoutDepense').'?error=Erreur d\'insertion !');
				}	
			}
			else
			{
				redirect(site_url('index.php/login/formAjoutDepense').'?error=Erreur d\'insertion !');	
			}
		}
		else
		{
			redirect(site_url('index.php/login/formAjoutDepense').'?error=Erreur d\'insertion !');
		}
	}

	public function ajoutEntrImpr()
	{
		$this->load->model('models');
		$this->load->helper('url');

		$data = $this->models->getDataConditionated('beneficiaire', ['idbeneficiaire'], ['nom'],[$this->input->post('nombeneficiaire')]);

		if(sizeof($data) != 0)
		{
			$this->models->insert('entree', ['idbeneficiaire', 'montant', 'dateentree', 'motif'], [$data[0]['idbeneficiaire'], $this->input->post('montant'), $this->input->post('date'), $this->input->post('motif')]);
			redirect(site_url('index.php/login/formEntrImpr').'?succes=Inséré avec succès !');	
		}
		else
		{
			redirect(site_url('index.php/login/formEntrImpr').'?error=Erreur d\'insertion !');
		}
	}

	public function ajoutCategorie()
	{
		$this->load->model('models');
		$this->load->helper('url');


	    $this->models->insert('categorie', ['nom', 'budget'], [$this->input->post('nom'), $this->input->post('budget')]);

		redirect(site_url('index.php/login/formCreerCategorie').'?succes=Catégorie créée !');
	}

	public function ajoutDepenseForm()
	{
		$this->load->model('models');
		$this->load->helper('url');

		$this->models->insert('depense', ['idbeneficiaire', 'idcategorie', 'datedepense', 'montant'], [$this->input->get('idbeneficiaire'), $this->input->get('idcategorie'), $this->input->get('datedepense'), $this->input->get('montant')]);
		redirect(site_url('index.php/login/formAjoutDepense').'?succes=Inséré avec succes !');	
	}

	public function ajoutMontant()
	{
		$this->load->model('models');
		$this->load->helper('url');

		$this->models->insert('entree', ['montant', 'dateentree', 'motif'], [$this->input->post('montant'), 'now()', 'salaire']);

		redirect(site_url('index.php/login/formCreerSalaireMensuel').'?succes=Salaire créée !');
	}

	public function ajoutUtilisateur()
	{
		$this->load->model('models');	
		$this->load->helper('url');

		$this->models->insert('utilisateur', ['nom', 'motdepasse', 'estbeneficiaire', 'estadmin', 'estsupprimee'], [$this->input->post('nom'), $this->input->post('motdepasse'), 'false', 'false', 'false']);
		redirect(site_url('index.php/login/formGestionUtilisateur').'?succes=Inséré avec succès !');
	}

	public function supprUtilisateur()
	{
		$this->load->model('models');	
		$this->load->helper('url');

		$this->models->update('utilisateur', ['estsupprimee'], ['true'], ['nom', 'motdepasse'], [$this->input->post('nom'), $this->input->post('motdepasse')]);

		redirect(site_url('index.php/login/formGestionUtilisateur').'?succes1=Supprimé avec succès !');
	}

	public function modifUtilisateur()
	{
		$this->load->model('models');
		$this->load->helper('url');

		$this->models->update('utilisateur', ['nom', 'motdepasse'], [$this->input->post('nommodif'), $this->input->post('motdepassemodif')], ['nom', 'motdepasse'], [$this->input->post('nom'), $this->input->post('motdepasse')]);

		redirect(site_url('index.php/login/formGestionUtilisateur').'?succes2=Modifié avec succès !');
	}

	public function ajoutBeneficiaire()
	{
		$this->load->model('models');	
		$this->load->helper('url');

		$this->models->insert('utilisateur', ['nom', 'motdepasse', 'estbeneficiaire', 'estadmin', 'estsupprimee'], [$this->input->post('nom'), $this->input->post('motdepasse'), 'true', 'false', 'false']);
		redirect(site_url('index.php/login/formGestionBeneficiaire').'?succes=Inséré avec succès !');
	}

	public function supprBeneficiaire()
	{
		$this->load->model('models');	
		$this->load->helper('url');

		$this->models->update('beneficiaire', ['estsupprimee'], ['true'], ['nom', 'motdepasse'], [$this->input->post('nom'), $this->input->post('motdepasse')]);

		redirect(site_url('index.php/login/formGestionBeneficiaire').'?succes1=Supprimé avec succès !');
	}

	public function modifBeneficiaire()
	{
		$this->load->model('models');
		$this->load->helper('url');

		$this->models->update('beneficiaire', ['nom', 'motdepasse'], [$this->input->post('nommodif'), $this->input->post('motdepassemodif')], ['nom', 'motdepasse'], [$this->input->post('nom'), $this->input->post('motdepasse')]);

		redirect(site_url('index.php/login/formGestionBeneficiaire').'?succes2=Modifié avec succès !');
	}

	public function tableauMensuel()
	{
		$this->load->model('models');
		$data = $this->models->getData('tableaumensuel', ['depensemontant', 'entreemontant', 'percentage', 'mois']);
		$data['datas'] = $data;
		$this->load->view('commun/tableauMensuel', $data);	
	}

	public function tabMensDepBenef()
	{
		$this->load->model('models');
		$data = $this->models->getData('depensemensuelparbeneficiaire', ['depensemontant', 'idbeneficiaire', 'mois']);
		$data['datas'] = $data;
		$this->load->view('commun/tableauMensuelDepense', $data);	
	}
}

